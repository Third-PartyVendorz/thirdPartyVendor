import os
from pathlib import Path

import psycopg2


def lambda_handler(event, context):
    """Connect using Terraform-provided settings and return the server version."""
    conn = psycopg2.connect(
        host=os.environ["DB_HOST"],
        port=int(os.environ.get("DB_PORT", "5432")),
        dbname=os.environ["DB_NAME"],
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
        sslmode="verify-full",
        sslrootcert=str(Path(__file__).with_name("global-bundle.pem")),
        connect_timeout=5,
        options="-c statement_timeout=10000",
    )
    try:
        with conn.cursor() as cur:
            schema_path = Path(__file__).with_name("schema.sql")
            cur.execute(schema_path.read_text(encoding="utf-8"))

            cur.execute("SELECT version();")
            version = cur.fetchone()[0]
        return {
            "statusCode": 200,
            "message": "Schema initialized successfully",
            "version": version,
        }
    finally:
        # A psycopg2 connection context manager alone does not close the socket.
        conn.close()